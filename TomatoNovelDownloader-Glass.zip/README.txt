番茄小说下载器 · 液态玻璃版（TomatoNovelDownloader-Glass）
============================================================

这是对目录下的 TomatoNovelDownloader-Win64.exe（v2.4.13，开源项目
zhongbai2333/Tomato-Novel-Downloader，Rust 命令行工具）的 UI 改造成品：
原程序没有图形界面，本版本为其套上了「液态玻璃（Liquid Glass）」风格的
桌面界面，使用 WebView2 渲染，并自动托管原下载器内核（--server 模式）。

运行方式
--------
双击 TomatoNovelDownloader-Glass.exe 即可。窗口为无边框液态玻璃样式，
支持：拖动顶栏移动窗口、双击顶栏最大化、右侧最小化/最大化/关闭按钮、
拖拽窗口边缘调整大小。

功能
----
- 概览：内核版本 / 预热状态 / 保存目录 / 监听地址 / 程序更新与自更新
- 搜索：按书名、Book ID、分享链接（fanqienovel.com / changdunovel.com）搜索并预览后下载
- 任务：实时进度、排队/完成/失败/部分失败/已取消/待配置状态，取消、重试、配置书名/格式
- 历史：下载记录与关键字筛选
- 更新：扫描本地书目，发现最新章节并更新
- 下载库：浏览已下载文件、打包下载、保存到任意位置
- 设置：快捷配置 / 完整配置（分组表单）/ YAML 编辑

目录结构
--------
TomatoNovelDownloader-Glass.exe  桌面壳（WebView2 + 液态玻璃窗口 + API 代理）
WebView2Loader.dll               WebView2 原生加载器（x86）
Microsoft.Web.WebView2.*.dll     WebView2 托管程序集
ui\                              液态玻璃前端（index.html / style.css / app.js）
webview2-data\                   浏览器数据目录（自动生成）
log.txt                          运行日志（自动生成）

说明与已知事项
--------------
- 关闭本程序时会同步关闭它拉起的下载器内核；若检测到已有内核在运行则复用、不关闭。
- 启动后内核监听 127.0.0.1:18423（固定端口），前端经本机代理同源访问，无需额外配置。
- 若搜索/预览返回 502：是番茄官方 API 在当前网络环境不可用（原版工具同样如此），
  可稍后重试，或在「设置 → API」中配置可用接口。
- 若开启了 Web UI 密码（--password），界面会自动弹出登录框。
- 修改 ui\ 下的 HTML/CSS/JS 后重启程序即可生效（无需重新编译）。
