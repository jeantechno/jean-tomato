/* ============================================================
   番茄小说下载器 · 液态玻璃版 前端逻辑
   通过本地代理(同源)访问下载器 HTTP API
   ============================================================ */

'use strict';

/* ---------- 基础工具 ---------- */

const $ = (id) => document.getElementById(id);
const esc = (s) => (s ?? '').toString().replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const encodePath = (p) => (p || '').toString().split('/').map(encodeURIComponent).join('/');

function fmtBytes(n) {
  const x = Number(n || 0);
  if (!isFinite(x) || x <= 0) return '0 B';
  const k = 1024, sizes = ['B','KB','MB','GB','TB'];
  const i = Math.floor(Math.log(x) / Math.log(k));
  return (x / Math.pow(k, i)).toFixed(i === 0 ? 0 : 1) + ' ' + sizes[i];
}
function fmtTime(ms) {
  const x = Number(ms || 0);
  if (!isFinite(x) || x <= 0) return '';
  const d = new Date(x);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

let toastTimer = null;
function toast(msg, isErr) {
  const wrap = $('toastWrap');
  const t = document.createElement('div');
  t.className = 'toast' + (isErr ? ' err' : '');
  t.textContent = msg;
  wrap.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; }, 2600);
  setTimeout(() => t.remove(), 3000);
}

/* ---------- 窗口控制（桥接到宿主） ---------- */

const HOST_BRIDGE = (() => {
  try {
    if (window.chrome && window.chrome.webview && window.chrome.webview.postMessage) {
      return {
        available: true,
        post: (o) => window.chrome.webview.postMessage(JSON.stringify(o)),
        onMsg: (cb) => window.chrome.webview.addEventListener('message', (e) => cb(e.data))
      };
    }
  } catch (_) {}
  return { available: false, post: () => {}, onMsg: () => {} };
})();

/* ---------- HTTP / 认证 ---------- */

let loginPromise = null;

async function fetchJson(url, opts) {
  const res = await fetch(url, Object.assign({ credentials: 'same-origin' }, opts || {}));
  if (res.status === 401) {
    await requireLogin();
    const res2 = await fetch(url, Object.assign({ credentials: 'same-origin' }, opts || {}));
    if (!res2.ok) throw new Error(`${res2.status} ${res2.statusText}`);
    return parseRes(res2);
  }
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`${res.status} ${res.statusText}${text ? ': ' + text : ''}`);
  }
  return parseRes(res);
}
function parseRes(res) {
  const ct = res.headers.get('content-type') || '';
  return ct.includes('application/json') ? res.json() : res.text();
}

function showLogin(show) {
  const m = $('loginModal');
  if (!m) return;
  m.classList.toggle('open', show);
  if (show) setTimeout(() => { const i = $('loginPassword'); if (i) i.focus(); }, 60);
}
async function requireLogin() {
  if (loginPromise) return loginPromise;
  showLogin(true);
  const msg = $('loginMsg');
  if (msg) msg.textContent = '';
  loginPromise = new Promise((resolve, reject) => {
    const form = $('loginForm');
    const handler = async (e) => {
      e.preventDefault();
      const pw = ($('loginPassword')?.value || '').toString();
      try {
        const res = await fetch('/api/login', {
          method: 'POST', credentials: 'same-origin',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ password: pw })
        });
        if (!res.ok) { if (msg) msg.textContent = '密码错误'; return; }
        showLogin(false);
        form.removeEventListener('submit', handler);
        resolve(true);
      } catch (err) {
        if (msg) msg.textContent = String(err || '登录失败');
      }
    };
    form.addEventListener('submit', handler);
  }).finally(() => { loginPromise = null; });
  return loginPromise;
}

/* ---------- 工具函数 ---------- */

function parseBookId(input) {
  const trimmed = (input ?? '').toString().trim();
  if (!trimmed) return '';
  if (/^[0-9]+$/.test(trimmed)) return trimmed;
  const urlMatch = trimmed.match(/https?:\/\/\S+/i);
  const target = urlMatch ? urlMatch[0] : trimmed;
  const qs = target.match(/(?:^|[?&#])(?:book_id|bookId)=([0-9]+)/i);
  if (qs && qs[1]) return qs[1];
  const page = target.match(/\/page\/([0-9]+)/i);
  if (page && page[1]) return page[1];
  const allowed = new Set(['changdunovel.com', 'www.changdunovel.com', 'fanqienovel.com', 'www.fanqienovel.com', 'fqnovel.com', 'www.fqnovel.com']);
  try {
    const parsed = new URL(target);
    if ((parsed.protocol === 'http:' || parsed.protocol === 'https:') && allowed.has(parsed.hostname.toLowerCase()) && /^\/t\/[A-Za-z0-9_-]+\/?$/.test(parsed.pathname)) return target;
  } catch (_) {}
  return '';
}

const HEIC_RE = /[\/.](heic|heif)(?:$|[?#])/i;
function coverCandidates(p) {
  const list = [];
  for (const u of [p.detail_cover_url, p.cover_url]) {
    const v = (u || '').toString().trim();
    if (!v) continue;
    if (!(v.startsWith('http://') || v.startsWith('https://') || v.startsWith('/'))) continue;
    if (!list.includes(v)) list.push(v);
  }
  return list;
}

function setTheme(theme) {
  if (theme === 'light' || theme === 'dark') document.documentElement.setAttribute('data-theme', theme);
  else document.documentElement.removeAttribute('data-theme');
}
function themeIcon(theme) {
  const dark = theme === 'dark' || (!theme && window.matchMedia('(prefers-color-scheme: dark)').matches);
  $('themeIcon').innerHTML = dark
    ? '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>'
    : '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>';
}

/* ---------- 导航 ---------- */

function switchSection(hash) {
  if (!hash || hash === '#') hash = '#status';
  document.querySelectorAll('.nav a').forEach(a => a.classList.toggle('active', a.getAttribute('href') === hash));
  document.querySelectorAll('.section').forEach(s => s.classList.toggle('active', '#' + s.id === hash));
  const link = document.querySelector(`.nav a[href="${hash}"]`);
  if (link) {
    $('pageTitle').textContent = link.dataset.title || '';
    $('pageSub').textContent = link.dataset.sub || '';
  }
}

/* ---------- 概览 ---------- */

let lastIidMessage = '';

async function refreshStatus() {
  const data = await fetchJson('/api/status');
  $('stVersion').textContent = data.version || '—';
  $('versionChip').textContent = 'v' + (data.version || '—');
  const pe = (data.prewarm_error || '').toString();
  $('stPrewarm').textContent = pe ? '预热失败' : (data.prewarm_in_progress ? '预热中…' : '就绪');
  $('stPrewarm').style.color = pe ? '#ff9aa0' : '';
  $('stSaveDir').textContent = data.save_dir || '';
  $('stBind').textContent = data.bind_addr || '';
  $('stBind').textContent += data.locked ? ' · 已锁定' : '';
  const banner = $('iidBanner');
  if (pe) {
    banner.textContent = '⚠️ ' + pe;
    banner.classList.remove('hidden');
    if (pe !== lastIidMessage) { lastIidMessage = pe; openModal('iidModal'); $('iidBody').textContent = pe; }
  } else {
    banner.classList.add('hidden');
  }
  setOnline(true);
  return data;
}

function setOnline(up) {
  const hero = $('offlineHero');
  if (up) { if (hero) hero.remove(); return; }
  if (hero) return;
  const wrap = $('status');
  const div = document.createElement('div');
  div.id = 'offlineHero';
  div.className = 'card glass offline-hero';
  div.innerHTML = '<div class="em">📡</div><h3>无法连接下载器内核</h3><p>后端服务未启动或尚未就绪，请点击重试。</p><button class="btn primary" id="offlineRetry">重试连接</button>';
  wrap.insertBefore(div, wrap.firstChild);
  $('offlineRetry').addEventListener('click', () => { toast('正在重试…'); HOST_BRIDGE.post({ cmd: 'retry-backend' }); });
}

/* ---------- 程序更新 ---------- */

const DISMISS_KEY = 'tnd.dismissed_release_tag';
let selfUpdatePollTimer = null, selfUpdateWasRunning = false;

function dismissedTag() { try { return localStorage.getItem(DISMISS_KEY) || ''; } catch { return ''; } }
function setDismissedTag(t) { try { localStorage.setItem(DISMISS_KEY, t || ''); } catch {} }

async function refreshAppUpdate(manual) {
  const hint = $('appUpdateHint'), body = $('appUpdateBody');
  if (hint) hint.textContent = manual ? '检查中…' : '';
  const data = await fetchJson('/api/app_update');
  const tag = (data.latest_tag || '').toString();
  const has = !!data.has_update;
  if (body) body.textContent = data.latest_body || '';
  const link = $('appUpdateLink');
  if (link) link.href = data.latest_url || '#';
  const show = has && tag && dismissedTag() !== tag;
  $('appUpdateBanner').classList.toggle('hidden', !show);
  if (show) $('appUpdateText').textContent = `发现新版本 ${tag}`;
  if (hint) hint.textContent = !has ? (manual ? '已是最新版本' : '') : (dismissedTag() === tag ? '已忽略该版本提醒' : '');
}

function renderSelfUpdate(st) {
  const wrap = $('selfUpdateWrap');
  const stt = (st?.state || 'idle').toString();
  const pct = Number(st?.percent || 0);
  wrap.classList.toggle('hidden', stt === 'idle');
  if (stt === 'idle') return;
  $('selfUpdateStage').textContent = (st?.stage || '').toString();
  $('selfUpdateMsg').textContent = (st?.message || '').toString();
  $('selfUpdateBar').style.width = `${Math.max(0, Math.min(100, pct))}%`;
  $('selfUpdatePct').textContent = `${Math.max(0, Math.min(100, pct))}%`;
}

async function pollSelfUpdate() {
  try {
    const st = await fetchJson('/api/self_update');
    renderSelfUpdate(st);
    const s = (st?.state || '').toString();
    if (s === 'running') {
      selfUpdateWasRunning = true;
      if (!selfUpdatePollTimer) selfUpdatePollTimer = setInterval(pollSelfUpdate, 1000);
    } else {
      if (selfUpdatePollTimer) { clearInterval(selfUpdatePollTimer); selfUpdatePollTimer = null; }
      if (selfUpdateWasRunning) { selfUpdateWasRunning = false; window.location.reload(); }
    }
  } catch (_) {
    if (selfUpdateWasRunning) { selfUpdateWasRunning = false; window.location.reload(); }
  }
}

/* ---------- 搜索 / 预览 ---------- */

let currentPreviewId = null, currentPreviewData = null;

async function doSearch(q) {
  const out = $('searchResults');
  out.innerHTML = '<tr class="empty-row"><td colspan="4">搜索中…</td></tr>';
  const data = await fetchJson(`/api/search?q=${encodeURIComponent(q)}`);
  const items = data.items || [];
  if (!items.length) { out.innerHTML = '<tr class="empty-row"><td colspan="4">无结果</td></tr>'; return; }
  out.innerHTML = '';
  for (const b of items) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${esc(b.title ?? '')}</td>
      <td>${esc(b.author ?? '')}</td>
      <td><code>${esc(b.book_id)}</code></td>
      <td><button class="btn sm primary" data-bookid="${esc(b.book_id)}">下载</button></td>`;
    out.appendChild(tr);
  }
}

async function openPreview(bookId) {
  currentPreviewId = bookId; currentPreviewData = null;
  openModal('previewModal');
  const load = $('previewLoading'), data = $('previewData');
  load.classList.remove('hidden'); data.classList.add('hidden');
  $('previewRangeInput').value = '';
  $('previewRangeHint').textContent = '';
  try {
    const p = await fetchJson(`/api/preview/${encodeURIComponent(bookId)}`);
    currentPreviewData = p;
    load.classList.add('hidden'); data.classList.remove('hidden');
    $('previewTitle').textContent = p.book_name || '未知书名';
    const orig = $('previewOrigTitle');
    if (p.original_book_name && p.original_book_name !== p.book_name) { orig.textContent = '原名：' + p.original_book_name; orig.classList.remove('hidden'); }
    else orig.classList.add('hidden');
    $('previewAuthor').textContent = p.author ? '作者：' + p.author : '作者：未知';
    const stats = $('previewStats'); stats.innerHTML = '';
    const parts = [];
    if (p.chapter_count) parts.push(`章节 ${p.chapter_count}`);
    if (p.finished !== null && p.finished !== undefined) parts.push(p.finished ? '完结' : '连载');
    if (p.word_count) { const w = Number(p.word_count); parts.push(w >= 10000 ? (w / 10000).toFixed(1) + ' 万字' : w + ' 字'); }
    if (p.score != null) parts.push(`评分 ${Number(p.score).toFixed(1)}`);
    if (p.read_count_text || p.read_count) parts.push('阅读 ' + (p.read_count_text || p.read_count));
    parts.forEach(x => { const s = document.createElement('span'); s.textContent = x; stats.appendChild(s); });
    $('previewDesc').textContent = p.description || '暂无简介';
    const tags = $('previewTags'); tags.innerHTML = '';
    (p.tags || []).forEach(t => { const s = document.createElement('span'); s.className = 'badge'; s.textContent = t; tags.appendChild(s); });
    const ch = $('previewChapters'); ch.innerHTML = '';
    const info = [];
    if (p.chapter_count) info.push(`总章节数 ${p.chapter_count}`);
    if (p.first_chapter_title) info.push(`首章 ${p.first_chapter_title}`);
    if (p.last_chapter_title) info.push(`末章 ${p.last_chapter_title}`);
    if (p.category) info.push(`分类 ${p.category}`);
    info.forEach(x => { const d = document.createElement('div'); d.textContent = x; ch.appendChild(d); });
    const img = $('previewCover');
    const cands = coverCandidates(p);
    let idx = 0;
    const loadNext = () => {
      if (idx >= cands.length) { img.removeAttribute('src'); img.classList.add('hidden'); img.onerror = null; return; }
      img.src = cands[idx++]; img.classList.remove('hidden');
    };
    img.onerror = loadNext;
    loadNext();
    if (p.chapter_count) $('previewRangeHint').textContent = `例如 1-10 下载第 1-10 章，1-${p.chapter_count} 下载全部`;
  } catch (err) {
    load.textContent = '加载失败：' + err;
    load.classList.remove('hidden');
  }
}

function closePreview() {
  if (currentPreviewId) {
    fetch('/api/preview/' + encodeURIComponent(currentPreviewId) + '/cleanup', { method: 'POST', credentials: 'same-origin' }).catch(() => {});
  }
  currentPreviewId = null; currentPreviewData = null;
  closeModal('previewModal');
}

async function confirmPreview() {
  if (!currentPreviewId || !currentPreviewData) { closePreview(); return; }
  const bookId = currentPreviewId;
  const rangeText = $('previewRangeInput').value.trim();
  let rangeStart = null, rangeEnd = null;
  if (rangeText) {
    const total = currentPreviewData.chapter_count || 0;
    if (!total) { $('previewRangeHint').textContent = '章节数未知，无法使用范围下载'; $('previewRangeHint').classList.add('error'); return; }
    const parts = rangeText.split('-').map(s => s.trim());
    if (parts.length !== 2) { $('previewRangeHint').textContent = '格式应为 start-end，例如 1-10'; $('previewRangeHint').classList.add('error'); return; }
    const s = parts[0] === '' ? 1 : parseInt(parts[0], 10);
    const e = parts[1] === '' ? total : parseInt(parts[1], 10);
    if (isNaN(s) || isNaN(e) || s < 1 || e < 1 || s > e || e > total) { $('previewRangeHint').textContent = `范围无效 (1-${total})`; $('previewRangeHint').classList.add('error'); return; }
    rangeStart = s; rangeEnd = e;
  }
  $('previewRangeHint').classList.remove('error');
  closePreview();
  try {
    const payload = { book_id: bookId };
    if (rangeStart !== null) { payload.range_start = rangeStart; payload.range_end = rangeEnd; }
    await fetchJson('/api/jobs', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload) });
    toast('已创建下载任务');
    await refreshJobs();
    window.location.hash = '#jobs';
  } catch (err) { toast('创建任务失败：' + err, true); }
}

async function startDownloadDirect(bookId) {
  await fetchJson('/api/jobs', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ book_id: bookId }) });
  await refreshJobs();
}

/* ---------- 任务 ---------- */

async function refreshJobs() {
  const data = await fetchJson('/api/jobs');
  const tbody = $('jobsBody');
  const items = data.items || [];
  tbody.innerHTML = '';
  for (const it of items) {
    const tr = document.createElement('tr');
    const saved = it.progress ? it.progress.saved_chapters : 0;
    const total = it.progress ? it.progress.chapter_total : 0;
    const pct = total > 0 ? Math.min(100, Math.round(saved / total * 100)) : 0;
    const title = it.title || it.book_id || '';
    const hasBookOpts = (it.book_name_options || []).length > 0;
    const hasFmtOpts = (it.format_options || []).length > 0;
    const needsCfg = hasBookOpts || hasFmtOpts;
    let st = (it.state || '').toLowerCase();
    if (st === 'done' && total > 0 && saved < total) st = 'partial';
    let badge, action;
    if (needsCfg) {
      const kind = hasBookOpts ? 'book_name' : 'format';
      badge = '<span class="badge warning">待配置</span>';
      action = `<button class="btn sm warn" data-cfg="${esc(it.id)}|${kind}">配置…</button>`;
    } else switch (st) {
      case 'running': badge = `<span class="badge info">${pct}%</span>`; action = `<button class="btn sm ghost" data-cancel="${esc(it.id)}">取消</button>`; break;
      case 'queued': badge = '<span class="badge">排队中</span>'; action = `<button class="btn sm ghost" data-cancel="${esc(it.id)}">取消</button>`; break;
      case 'done': badge = '<span class="badge success">完成</span>'; action = `<button class="btn sm success" data-clear="${esc(it.id)}">完成</button>`; break;
      case 'failed': badge = '<span class="badge danger">失败</span>'; action = `<button class="btn sm warn" data-retry="${esc(it.book_id)}|${esc(it.id)}">重试</button>`; break;
      case 'partial': badge = '<span class="badge warning">部分失败</span>'; action = `<button class="btn sm warn" data-retry="${esc(it.book_id)}|${esc(it.id)}">重试</button>`; break;
      case 'canceled': badge = '<span class="badge">已取消</span>'; action = `<button class="btn sm ghost" data-retry="${esc(it.book_id)}|${esc(it.id)}">重试</button>`; break;
      default: badge = esc(it.state || ''); action = '';
    }
    const progHtml = (st === 'running' || st === 'queued')
      ? `<div class="progress"><i style="width:${pct}%"></i></div><span style="font-size:12px;color:var(--ink-2)">${saved}/${total}</span>`
      : (it.progress ? `${saved}/${total}` : '');
    tr.innerHTML = `
      <td><code>${esc(it.id)}</code></td>
      <td>${esc(title)}</td>
      <td>${badge}</td>
      <td>${progHtml}</td>
      <td>${action}</td>`;
    tbody.appendChild(tr);
  }
  if (!items.length) tbody.innerHTML = '<tr class="empty-row"><td colspan="5">暂无任务（已完成超 2 小时自动隐藏）</td></tr>';
}

async function cancelJob(id) {
  await fetchJson(`/api/jobs/${encodeURIComponent(id)}/cancel`, { method: 'POST' });
  await refreshJobs();
}
async function clearJob(id) {
  await fetchJson(`/api/jobs/${encodeURIComponent(id)}`, { method: 'DELETE' });
  await refreshJobs();
}

/* ---------- 任务配置弹窗（书名/格式） ---------- */

let pendingCfg = null; // { kind, jobId }

async function openJobConfig(jobId, kind) {
  const data = await fetchJson(`/api/jobs?id=${encodeURIComponent(jobId)}`);
  const job = (data.items || [])[0];
  if (!job) throw new Error('任务不存在或已被清理');
  const hasBookOpts = (job.book_name_options || []).length > 0;
  const hasFmtOpts = (job.format_options || []).length > 0;
  if (hasBookOpts && (kind === 'book_name' || !hasFmtOpts)) return showChoices('bookName', job);
  if (hasFmtOpts) return showChoices('format', job);
  throw new Error('该任务没有待配置项');
}

function showChoices(kind, job) {
  pendingCfg = { kind, jobId: job.id };
  const isBook = kind === 'bookName';
  const modal = $(isBook ? 'bookNameModal' : 'formatModal');
  const box = $(isBook ? 'bookNameOptions' : 'formatOptions');
  $(isBook ? 'bookNameJobHint' : 'formatJobHint').textContent = (job.title || job.book_id || '') ? `《${job.title || job.book_id}》` : '';
  box.innerHTML = '';
  const opts = isBook ? (job.book_name_options || []) : (job.format_options || []);
  opts.forEach((opt, idx) => {
    const lab = document.createElement('label');
    lab.className = 'row';
    lab.innerHTML = `<input type="radio" name="${kind}Opt" value="${esc(opt.value)}" ${idx === 0 ? 'checked' : ''}><span>${esc(opt.label)}：${esc(opt.value)}</span>`;
    box.appendChild(lab);
  });
  openModal(isBook ? 'bookNameModal' : 'formatModal');
}

async function submitChoice() {
  if (!pendingCfg) return;
  const isBook = pendingCfg.kind === 'bookName';
  const sel = document.querySelector(`input[name="${isBook ? 'bookName' : 'format'}Opt"]:checked`);
  if (!sel) { toast('请先选择一个选项', true); return; }
  const path = isBook ? 'book_name' : 'format';
  try {
    await fetchJson(`/api/jobs/${encodeURIComponent(pendingCfg.jobId)}/${path}`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ value: sel.value })
    });
    closeModal(isBook ? 'bookNameModal' : 'formatModal');
    pendingCfg = null;
    await refreshJobs();
  } catch (err) { toast('提交失败：' + err, true); }
}

/* ---------- 历史 ---------- */

async function refreshHistory() {
  const hint = $('historyHint'), body = $('historyBody');
  const kw = ($('historyKeyword').value || '').toString().trim();
  if (hint) hint.textContent = '加载中…';
  body.innerHTML = '<tr class="empty-row"><td colspan="6">加载中…</td></tr>';
  const qs = new URLSearchParams();
  qs.set('limit', '200');
  if (kw) qs.set('q', kw);
  const data = await fetchJson(`/api/history?${qs.toString()}`);
  const items = data.items || [];
  body.innerHTML = '';
  for (const it of items) {
    const ok = (it.status || '').toString().toLowerCase() === 'success';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${esc(it.timestamp || '')}</td>
      <td>${esc(it.book_name || '')}</td>
      <td>${esc(it.author || '')}</td>
      <td><code>${esc(it.book_id || '')}</code></td>
      <td>${esc(it.progress || '')}</td>
      <td>${ok ? '<span class="badge success">成功</span>' : '<span class="badge danger">失败</span>'}</td>`;
    body.appendChild(tr);
  }
  if (!items.length) body.innerHTML = '<tr class="empty-row"><td colspan="6">暂无历史记录</td></tr>';
  if (hint) hint.textContent = `共 ${items.length} 条`;
}

/* ---------- 更新扫描 ---------- */

let updatesPollTimer = null;
function scheduleUpdatesPoll() {
  if (updatesPollTimer) clearTimeout(updatesPollTimer);
  updatesPollTimer = setTimeout(() => { updatesPollTimer = null; refreshUpdates(false).catch(() => {}); }, 1000);
}

async function refreshUpdates(start) {
  const hint = $('updatesHint'), tbody = $('updatesBody');
  if (start) {
    if (updatesPollTimer) { clearTimeout(updatesPollTimer); updatesPollTimer = null; }
    if (hint) hint.textContent = '扫描中…';
    tbody.innerHTML = '<tr class="empty-row"><td colspan="7">启动扫描中…</td></tr>';
  }
  const data = await fetchJson(start ? '/api/updates' : '/api/updates?start=false');
  const updates = data.updates || [];
  const noUpdates = data.no_updates || [];
  const scanned = Number(data.scanned || updates.length + noUpdates.length || 0);
  const total = Number(data.total || updates.length + noUpdates.length || 0);
  const running = !!data.running;
  if (hint) {
    if (data.error) hint.textContent = '扫描失败：' + data.error;
    else if (running) hint.textContent = `扫描中 ${scanned}/${total}，可更新 ${updates.length} / 无更新 ${noUpdates.length}`;
    else hint.textContent = `可更新 ${updates.length} / 无更新 ${noUpdates.length} / 总计 ${updates.length + noUpdates.length}`;
  }
  tbody.innerHTML = '';
  for (const it of updates) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${esc(it.book_name || '')}</td>
      <td><code>${esc(it.book_id || '')}</code></td>
      <td>${Number(it.local_total || 0)}</td>
      <td>${Number(it.remote_total || 0)}</td>
      <td><span class="badge info">+${Number(it.new_count || 0)}</span></td>
      <td>${Number(it.local_failed || 0)}</td>
      <td><button class="btn sm primary" data-bookid="${esc(it.book_id || '')}">更新</button></td>`;
    tbody.appendChild(tr);
  }
  if (!updates.length) {
    tbody.innerHTML = running
      ? `<tr class="empty-row"><td colspan="7">${esc(scanned > 0 ? `已检查 ${scanned} 本，暂未发现可更新小说，继续扫描中…` : '扫描中，结果会自动出现…')}</td></tr>`
      : '<tr class="empty-row"><td colspan="7">暂无可更新的小说</td></tr>';
  }
  if (running) scheduleUpdatesPoll();
}

/* ---------- 下载库 ---------- */

let libraryPath = '', libraryPollTimer = null;

function scheduleLibraryPoll() {
  if (libraryPollTimer) clearTimeout(libraryPollTimer);
  libraryPollTimer = setTimeout(() => { libraryPollTimer = null; refreshLibrary(false).catch(() => {}); }, 700);
}

async function refreshLibrary(start) {
  if (start && libraryPollTimer) { clearTimeout(libraryPollTimer); libraryPollTimer = null; }
  const params = new URLSearchParams();
  if (libraryPath) params.set('path', libraryPath);
  params.set('start', start ? 'true' : 'false');
  const data = await fetchJson(`/api/library?${params.toString()}`);
  const items = data.items || [];
  libraryPath = (data.path || '').toString();
  const running = !!data.running;
  $('libPath').textContent = libraryPath ? '/' + libraryPath : '/';
  $('libBack').disabled = !libraryPath;
  const hint = $('libHint');
  if (data.error) hint.textContent = '读取失败：' + data.error;
  else if (running) hint.textContent = `分批读取中，已发现 ${items.length} 项 / 已检查 ${data.scanned || items.length}`;
  else hint.textContent = `共 ${items.length} 项`;
  const tbody = $('libraryBody');
  tbody.innerHTML = '';
  for (const it of items) {
    const kind = it.kind || 'file';
    const rel = it.rel_path || '';
    const name = it.name || rel;
    const sizeText = kind === 'dir'
      ? (it.file_count == null ? '文件夹' : `${fmtBytes(it.size)} · ${it.file_count} 个文件`)
      : fmtBytes(it.size);
    const tr = document.createElement('tr');
    if (kind === 'dir') {
      tr.innerHTML = `
        <td><button class="btn sm ghost" data-dir="${esc(rel)}">打开</button> <span style="margin-left:4px">📁 ${esc(name)}</span></td>
        <td>${esc(sizeText)}</td>
        <td>${esc(fmtTime(it.modified_ms))}</td>
        <td><a class="btn sm" href="/download-zip/${encodePath(rel)}">打包下载</a></td>`;
    } else {
      tr.innerHTML = `
        <td><span style="opacity:.75">📄</span> <a class="btn-link" href="/download/${encodePath(rel)}">${esc(name)}</a> <span class="badge">${esc(it.ext || '')}</span></td>
        <td>${esc(sizeText)}</td>
        <td>${esc(fmtTime(it.modified_ms))}</td>
        <td><a class="btn sm primary" href="/download/${encodePath(rel)}">下载</a></td>`;
    }
    tbody.appendChild(tr);
  }
  if (!items.length) {
    tbody.innerHTML = running
      ? '<tr class="empty-row"><td colspan="4">正在分批读取下载库，结果会陆续出现…</td></tr>'
      : '<tr class="empty-row"><td colspan="4">暂无文件，先下载一本书吧</td></tr>';
  }
  if (running) scheduleLibraryPoll();
}

/* ---------- 设置 ---------- */

async function refreshConfig() {
  const data = await fetchJson('/api/config');
  $('cfgNovelFormat').value = (data.novel_format || 'txt').toString();
  $('cfgEnableAudiobook').checked = !!data.enable_audiobook;
  $('cfgAudiobookFormat').value = (data.audiobook_format || 'mp3').toString();
}

async function saveConfig() {
  await fetchJson('/api/config', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      novel_format: $('cfgNovelFormat').value,
      enable_audiobook: !!$('cfgEnableAudiobook').checked,
      audiobook_format: $('cfgAudiobookFormat').value
    })
  });
}

async function refreshRawConfig() {
  const data = await fetchJson('/api/config/raw');
  $('cfgRaw').value = (data.yaml || '').toString();
  $('cfgRawMsg').textContent = data.generated ? '已生成默认配置（未找到配置文件）' : '';
}
async function saveRawConfig() {
  await fetchJson('/api/config/raw', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ yaml: $('cfgRaw').value }) });
}

/* ---- 完整配置 ---- */

const VOICES = [
  ['zh-CN-XiaoxiaoNeural', 'zh-CN-XiaoxiaoNeural (女)'], ['zh-CN-XiaoyiNeural', 'zh-CN-XiaoyiNeural (女)'],
  ['zh-CN-YunjianNeural', 'zh-CN-YunjianNeural (男)'], ['zh-CN-YunxiNeural', 'zh-CN-YunxiNeural (男)'],
  ['zh-CN-YunxiaNeural', 'zh-CN-YunxiaNeural (男)'], ['zh-CN-YunyangNeural', 'zh-CN-YunyangNeural (男)'],
  ['zh-CN-liaoning-XiaobeiNeural', 'zh-CN-liaoning-XiaobeiNeural (女)'], ['zh-CN-shaanxi-XiaoniNeural', 'zh-CN-shaanxi-XiaoniNeural (女)'],
  ['zh-HK-HiuGaaiNeural', 'zh-HK-HiuGaaiNeural (女)'], ['zh-HK-HiuMaanNeural', 'zh-HK-HiuMaanNeural (女)'],
  ['zh-HK-WanLungNeural', 'zh-HK-WanLungNeural (男)'], ['zh-TW-HsiaoChenNeural', 'zh-TW-HsiaoChenNeural (女)']
];

const CFG_SCHEMA = [
  { title: '基础与格式', fields: [
    { key: 'save_path', label: '保存路径', type: 'text' },
    { key: 'novel_format', label: '小说格式', type: 'select', options: [['txt','txt'],['epub','epub'],['pdf','pdf'],['bulk_txt','散装文件'],['ask_after_download','下载后选择']] },
    { key: 'first_line_indent_em', label: '首行缩进 (em)', type: 'number', parse: 'float', step: '0.1', min: '0' },
    { key: 'auto_clear_dump', label: '自动清理缓存', type: 'bool' },
    { key: 'auto_open_downloaded_files', label: '下载完成后自动打开', type: 'bool' },
    { key: 'allow_overwrite_files', label: '允许覆盖已存在文件', type: 'bool' },
    { key: 'preferred_book_name_field', label: '优先书名字段', type: 'select', options: [['book_name','默认书名'],['original_book_name','原始书名'],['book_short_name','短书名'],['ask_after_download','下载完后选择']] }
  ]},
  { title: '网络与调度', fields: [
    { key: 'max_workers', label: '最大线程数', type: 'number', parse: 'int', min: '1' },
    { key: 'request_timeout', label: '请求超时 (s)', type: 'number', parse: 'int', min: '1' },
    { key: 'max_retries', label: '最大重试次数', type: 'number', parse: 'int', min: '0' },
    { key: 'min_connect_timeout', label: '最小连接超时 (s)', type: 'number', parse: 'float', step: '0.1', min: '0' },
    { key: 'min_wait_time', label: '最小等待 (ms)', type: 'number', parse: 'int', min: '0' },
    { key: 'max_wait_time', label: '最大等待 (ms)', type: 'number', parse: 'int', min: '0' }
  ]},
  { title: 'API', fields: [
    { key: 'use_official_api', label: '使用官方 API', type: 'bool' },
    { key: 'api_endpoints', label: 'API 列表', type: 'list', placeholder: '每行一条或用逗号分隔' }
  ]},
  { title: '段评', fields: [
    { key: 'enable_segment_comments', label: '启用段评', type: 'bool' },
    { key: 'segment_comments_top_n', label: '每段评论数上限', type: 'number', parse: 'int', min: '1' },
    { key: 'segment_comments_workers', label: '段评并发线程数', type: 'number', parse: 'int', min: '1' }
  ]},
  { title: '媒体下载', fields: [
    { key: 'download_comment_images', label: '下载评论图片', type: 'bool' },
    { key: 'download_comment_avatars', label: '下载评论头像', type: 'bool' },
    { key: 'media_download_workers', label: '媒体下载线程数', type: 'number', parse: 'int', min: '1' },
    { key: 'blocked_media_domains', label: '阻止的图片域名', type: 'list', placeholder: '每行一个域名' },
    { key: 'force_convert_images_to_jpeg', label: '强制转成 JPEG', type: 'bool' },
    { key: 'jpeg_retry_convert', label: '失败重试再转 JPEG', type: 'bool' },
    { key: 'jpeg_quality', label: 'JPEG 质量 (0-100)', type: 'number', parse: 'int', min: '0', max: '100' },
    { key: 'convert_heic_to_jpeg', label: 'HEIC 转 JPEG', type: 'bool' },
    { key: 'keep_heic_original', label: '保留 HEIC 原图', type: 'bool' },
    { key: 'media_limit_per_chapter', label: '单章节媒体上限', type: 'number', parse: 'int', min: '0' },
    { key: 'media_max_dimension_px', label: '媒体最大尺寸 (px)', type: 'number', parse: 'int', min: '0' }
  ]},
  { title: '有声书', fields: [
    { key: 'enable_audiobook', label: '启用有声书', type: 'bool' },
    { key: 'audiobook_voice', label: '发音人', type: 'voice' },
    { key: 'audiobook_tts_provider', label: 'TTS 服务类型', type: 'select', options: [['edge','edge'],['third_party','third_party']] },
    { key: 'audiobook_tts_api_url', label: '第三方 TTS API 地址', type: 'text' },
    { key: 'audiobook_tts_api_token', label: '第三方 TTS Token', type: 'text' },
    { key: 'audiobook_tts_model', label: '第三方 TTS 模型', type: 'text' },
    { key: 'audiobook_rate', label: '语速调整', type: 'text' },
    { key: 'audiobook_volume', label: '音量调整', type: 'text' },
    { key: 'audiobook_pitch', label: '音调调整', type: 'text' },
    { key: 'audiobook_format', label: '输出格式', type: 'select', options: [['mp3','mp3'],['wav','wav']] },
    { key: 'audiobook_concurrency', label: '并发生成章节数', type: 'number', parse: 'int', min: '1' }
  ]}
];

let currentFullConfig = {};

function renderFullConfig(cfg) {
  const body = $('configFullBody');
  body.innerHTML = '';
  for (const sec of CFG_SCHEMA) {
    const secEl = document.createElement('div');
    secEl.className = 'config-section';
    secEl.innerHTML = `<h4>${esc(sec.title)}</h4>`;
    for (const f of sec.fields) {
      const row = document.createElement('div');
      row.className = 'config-field';
      const lab = document.createElement('span');
      lab.className = 'field-label';
      lab.textContent = f.label;
      row.appendChild(lab);
      let input;
      if (f.type === 'bool') {
        input = document.createElement('input'); input.type = 'checkbox'; input.checked = !!cfg[f.key];
      } else if (f.type === 'voice') {
        const wrap = document.createElement('div'); wrap.className = 'voiceRow';
        const sel = document.createElement('select');
        sel.appendChild(new Option('自定义…', ''));
        VOICES.forEach(v => sel.appendChild(new Option(v[1], v[0])));
        const cur = (cfg[f.key] || '').toString();
        sel.value = VOICES.some(v => v[0] === cur) ? cur : '';
        const txt = document.createElement('input'); txt.type = 'text'; txt.value = cur; txt.placeholder = '输入或选择发音人';
        sel.addEventListener('change', () => { if (sel.value) txt.value = sel.value; });
        wrap.appendChild(sel); wrap.appendChild(txt);
        input = wrap;
        txt.dataset.key = f.key; txt.dataset.type = 'text';
      } else if (f.type === 'select') {
        input = document.createElement('select');
        f.options.forEach(o => input.appendChild(new Option(o[1], o[0])));
        if (f.key === 'novel_format' && cfg.ask_format_after_download) input.value = 'ask_after_download';
        else if (f.key === 'novel_format' && cfg.bulk_files) input.value = 'bulk_txt';
        else input.value = (cfg[f.key] ?? '').toString();
        input.dataset.key = f.key; input.dataset.type = 'select';
      } else if (f.type === 'list') {
        input = document.createElement('textarea');
        input.value = Array.isArray(cfg[f.key]) ? cfg[f.key].join('\n') : '';
        input.placeholder = f.placeholder || '';
        input.dataset.key = f.key; input.dataset.type = 'list';
      } else if (f.type === 'number') {
        input = document.createElement('input'); input.type = 'number';
        if (f.step) input.step = f.step; if (f.min) input.min = f.min; if (f.max) input.max = f.max;
        input.value = (cfg[f.key] ?? '').toString();
        input.dataset.key = f.key; input.dataset.type = 'number'; input.dataset.parse = f.parse || 'int';
      } else {
        input = document.createElement('input'); input.type = 'text';
        input.value = (cfg[f.key] ?? '').toString();
        input.dataset.key = f.key; input.dataset.type = 'text';
      }
      row.appendChild(input);
      secEl.appendChild(row);
    }
    body.appendChild(secEl);
  }
}

function collectFullConfig() {
  const out = Object.assign({}, currentFullConfig);
  document.querySelectorAll('#configFullBody [data-key]').forEach(el => {
    const key = el.dataset.key, type = el.dataset.type;
    if (!key || !type) return;
    if (type === 'bool') out[key] = !!el.checked;
    else if (type === 'list') out[key] = (el.value || '').split(/[\n,;]/).map(s => s.trim()).filter(s => s.length);
    else if (type === 'number') {
      const raw = (el.value || '').trim();
      if (!raw) return;
      const val = el.dataset.parse === 'float' ? parseFloat(raw) : parseInt(raw, 10);
      if (!Number.isNaN(val)) out[key] = val;
    } else out[key] = (el.value || '').toString();
  });
  const fmt = out.novel_format;
  if (fmt === 'ask_after_download') { out.ask_format_after_download = true; out.bulk_files = false; out.novel_format = (currentFullConfig.novel_format || 'txt').toString(); }
  else if (fmt === 'bulk_txt') { out.ask_format_after_download = false; out.bulk_files = true; out.novel_format = 'txt'; }
  else if (fmt) { out.ask_format_after_download = false; out.bulk_files = false; }
  return out;
}

async function loadFullConfig() {
  const msg = $('cfgFullMsg');
  msg.textContent = '加载中…';
  try {
    const cfg = await fetchJson('/api/config/full');
    currentFullConfig = cfg || {};
    renderFullConfig(currentFullConfig);
    msg.textContent = '';
  } catch (_) { msg.textContent = '加载失败'; }
}
async function saveFullConfig() {
  await fetchJson('/api/config/full', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(collectFullConfig()) });
}

/* ---------- 弹窗通用 ---------- */

function openModal(id) { $(id).classList.add('open'); }
function closeModal(id) { $(id).classList.remove('open'); }

let confirmCb = null;
function askConfirm(title, body, cb) {
  $('confirmTitle').textContent = title;
  $('confirmBody').textContent = body;
  confirmCb = cb;
  openModal('confirmModal');
}

/* ---------- 事件绑定 ---------- */

function wire() {
  // 导航
  window.addEventListener('hashchange', () => switchSection(window.location.hash));
  switchSection(window.location.hash);

  // 主题
  const THEME_KEY = 'tnd.theme';
  let theme = (() => { try { return localStorage.getItem(THEME_KEY); } catch { return null; } })();
  setTheme(theme);
  themeIcon(theme);
  $('themeToggle').addEventListener('click', () => {
    const cur = document.documentElement.getAttribute('data-theme');
    theme = cur === 'dark' ? 'light' : cur === 'light' ? null : (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'light' : 'dark');
    try { localStorage.setItem(THEME_KEY, theme || ''); } catch {}
    setTheme(theme); themeIcon(theme);
  });

  // 窗口控制
  $('winMin').addEventListener('click', () => HOST_BRIDGE.post({ cmd: 'min' }));
  $('winMax').addEventListener('click', () => HOST_BRIDGE.post({ cmd: 'max' }));
  $('winClose').addEventListener('click', () => HOST_BRIDGE.post({ cmd: 'close' }));
  const topbar = document.querySelector('.topbar');
  topbar.addEventListener('dblclick', (e) => { if (e.target.closest('.win-controls')) return; HOST_BRIDGE.post({ cmd: 'max' }); });
  let dragging = false, dragStart = null;
  topbar.addEventListener('mousedown', (e) => {
    if (e.target.closest('.win-controls') || e.button !== 0) return;
    dragging = true; dragStart = { x: e.screenX, y: e.screenY };
  });
  window.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    if (Math.abs(e.screenX - dragStart.x) > 3 || Math.abs(e.screenY - dragStart.y) > 3) {
      dragging = false;
      HOST_BRIDGE.post({ cmd: 'drag' });
    }
  });
  window.addEventListener('mouseup', () => { dragging = false; });

  // 宿主 → 页面
  HOST_BRIDGE.onMsg((data) => {
    if (data && data.type === 'acrylic') {
      document.documentElement.setAttribute('data-acrylic', data.on ? 'on' : 'off');
    } else if (data && data.type === 'backendState') {
      if (data.up) { setOnline(true); refreshAll().catch(() => {}); }
    }
  });

  // 概览
  $('appUpdateCheck').addEventListener('click', () => refreshAppUpdate(true).catch(e => toast(e, true)));
  $('appUpdateDismiss').addEventListener('click', async () => {
    try {
      const d = await fetchJson('/api/app_update');
      setDismissedTag(d.latest_tag || '');
      $('appUpdateBanner').classList.add('hidden');
      $('appUpdateHint').textContent = '已设置不再提醒';
    } catch (e) { toast(e, true); }
  });
  $('appSelfUpdate').addEventListener('click', async () => {
    try {
      await fetchJson('/api/self_update', { method: 'POST' });
      toast('自更新任务已启动');
      await pollSelfUpdate();
    } catch (e) { toast('自更新触发失败：' + e, true); }
  });

  // 搜索
  $('searchForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const q = $('q').value.trim();
    $('searchHint').textContent = '';
    const bookId = parseBookId(q);
    if (bookId) {
      try {
        await openPreview(bookId);
      } catch (err) { toast('创建任务失败：' + err, true); }
      return;
    }
    try { await doSearch(q); } catch (err) { toast('搜索失败：' + err, true); }
  });
  $('searchResults').addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-bookid]');
    if (!btn) return;
    openPreview(btn.dataset.bookid).catch(err => toast('加载失败：' + err, true));
  });

  // 预览
  $('previewConfirm').addEventListener('click', () => confirmPreview().catch(e => toast(e, true)));
  $('previewCancel').addEventListener('click', closePreview);
  $('previewClose').addEventListener('click', closePreview);

  // 任务
  $('jobsRefresh').addEventListener('click', () => refreshJobs().catch(e => toast(e, true)));
  $('jobsBody').addEventListener('click', (e) => {
    const cfgBtn = e.target.closest('button[data-cfg]');
    if (cfgBtn) { const [id, kind] = cfgBtn.dataset.cfg.split('|'); openJobConfig(id, kind).catch(err => toast(err, true)); return; }
    const cancelBtn = e.target.closest('button[data-cancel]');
    if (cancelBtn) { askConfirm('取消任务', '确认取消该任务并从列表中清理吗？', () => cancelJob(cancelBtn.dataset.cancel).catch(err => toast(err, true))); return; }
    const retryBtn = e.target.closest('button[data-retry]');
    if (retryBtn) { const [bookId, jobId] = retryBtn.dataset.retry.split('|'); startDownloadDirect(bookId).then(async () => { if (jobId) await clearJob(jobId).catch(() => {}); await refreshJobs(); }).catch(err => toast(err, true)); return; }
    const clearBtn = e.target.closest('button[data-clear]');
    if (clearBtn) { clearJob(clearBtn.dataset.clear).then(() => { window.location.hash = '#library'; refreshLibrary().catch(() => {}); }).catch(err => toast(err, true)); }
  });

  // 书名/格式弹窗
  $('bookNameConfirm').addEventListener('click', () => submitChoice().catch(e => toast(e, true)));
  $('formatConfirm').addEventListener('click', () => submitChoice().catch(e => toast(e, true)));
  $('bookNameClose').addEventListener('click', () => { closeModal('bookNameModal'); pendingCfg = null; });
  $('formatClose').addEventListener('click', () => { closeModal('formatModal'); pendingCfg = null; });
  $('bookNameCancel').addEventListener('click', () => { closeModal('bookNameModal'); pendingCfg = null; });
  $('formatCancel').addEventListener('click', () => { closeModal('formatModal'); pendingCfg = null; });

  // 历史
  $('historyRefresh').addEventListener('click', () => refreshHistory().catch(e => toast(e, true)));
  $('historyKeyword').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); refreshHistory().catch(err => toast(err, true)); } });

  // 更新
  $('updatesRefresh').addEventListener('click', () => refreshUpdates(true).catch(e => toast(e, true)));
  $('updatesBody').addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-bookid]');
    if (!btn) return;
    openPreview(btn.dataset.bookid).catch(err => toast('加载失败：' + err, true));
  });

  // 下载库
  $('libBack').addEventListener('click', () => {
    const parts = libraryPath.split('/').filter(Boolean);
    parts.pop();
    libraryPath = parts.join('/');
    refreshLibrary().catch(err => toast(err, true));
  });
  $('libraryBody').addEventListener('click', (e) => {
    const dirBtn = e.target.closest('button[data-dir]');
    if (!dirBtn) return;
    libraryPath = dirBtn.dataset.dir;
    refreshLibrary().catch(err => toast(err, true));
  });

  // 设置 tabs
  const tabs = document.querySelectorAll('.tab');
  const panels = { quick: $('configPanelQuick'), full: $('configPanelFull'), yaml: $('configPanelYaml') };
  let fullLoaded = false;
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.tab;
      tabs.forEach(t => t.classList.toggle('active', t === tab));
      Object.entries(panels).forEach(([k, p]) => p.classList.toggle('active', k === target));
      if (target === 'full' && !fullLoaded) { fullLoaded = true; loadFullConfig().catch(() => {}); }
    });
  });
  $('configForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('configMsg').textContent = '保存中…';
    try { await saveConfig(); $('configMsg').textContent = '已保存'; }
    catch (err) { $('configMsg').textContent = '保存失败'; toast(err, true); }
  });
  $('cfgFullSave').addEventListener('click', async () => {
    $('cfgFullMsg').textContent = '保存中…';
    try { await saveFullConfig(); await refreshConfig(); await refreshRawConfig(); $('cfgFullMsg').textContent = '已保存'; }
    catch (err) { $('cfgFullMsg').textContent = '保存失败'; toast(err, true); }
  });
  $('cfgRawReload').addEventListener('click', async () => {
    $('cfgRawMsg').textContent = '加载中…';
    try { await refreshRawConfig(); $('cfgRawMsg').textContent = '已加载'; }
    catch (err) { $('cfgRawMsg').textContent = '加载失败'; toast(err, true); }
  });
  $('cfgRawSave').addEventListener('click', async () => {
    $('cfgRawMsg').textContent = '保存中…';
    try { await saveRawConfig(); await refreshConfig(); $('cfgRawMsg').textContent = '已保存'; }
    catch (err) { $('cfgRawMsg').textContent = '保存失败'; toast(err, true); }
  });

  // 确认弹窗
  $('confirmOk').addEventListener('click', () => { closeModal('confirmModal'); if (confirmCb) confirmCb(); confirmCb = null; });
  $('confirmCancel').addEventListener('click', () => { closeModal('confirmModal'); confirmCb = null; });

  // IID
  $('iidOk').addEventListener('click', () => closeModal('iidModal'));

  // Esc
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if ($('loginModal').classList.contains('open')) { closeModal('loginModal'); return; }
    if ($('previewModal').classList.contains('open')) { closePreview(); return; }
    if ($('bookNameModal').classList.contains('open')) { closeModal('bookNameModal'); pendingCfg = null; return; }
    if ($('formatModal').classList.contains('open')) { closeModal('formatModal'); pendingCfg = null; return; }
    if ($('confirmModal').classList.contains('open')) { closeModal('confirmModal'); confirmCb = null; return; }
    if ($('iidModal').classList.contains('open')) { closeModal('iidModal'); }
  });
}

/* ---------- 启动 ---------- */

async function refreshAll() {
  await Promise.allSettled([refreshStatus(), refreshConfig(), refreshRawConfig()]);
  await Promise.allSettled([refreshJobs(), refreshHistory(), refreshLibrary(false)]);
  refreshUpdates(false).catch(() => {});
  refreshAppUpdate(false).catch(() => {});
  pollSelfUpdate().catch(() => {});
}

async function boot() {
  wire();
  try {
    await refreshAll();
    setInterval(() => refreshJobs().catch(() => {}), 1500);
    setInterval(() => refreshStatus().catch(() => { setOnline(false); }), 5000);
    setInterval(() => refreshAppUpdate(false).catch(() => {}), 6 * 60 * 60 * 1000);
  } catch (err) {
    console.error('boot failed:', err);
    setOnline(false);
  }
}

boot();
